<!DOCTYPE html>
<html>
<head>
	<title>My Volunteer</title>
	<link rel="stylesheet" type="text/css" href="../index.css">
	<link rel="stylesheet" type="text/css" href="../home.css">
	<link rel="stylesheet" type="text/css" href="../menu.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<?php include '../headcontent.html'; ?>

  <meta charset="utf-8" />
  <!-- <base href="http://myvolunteer.in/" /> -->
  <meta name="keywords" content="Events, Volunteer, Volunteering, Volunteers, Management, Events, Dublin, Fingal, Ireland, good, practice, Volunteer, Centre, Ireland, Management dublin, ireland, retention, motivation, recruitment, experts, selection, software, better impact, volunteer impact, Fingal County Council" />
  <meta name="description" content="Volunteer Management at Events" />
</head>
<body>

<div class="col-12 wrapper">
	<?php include '../topmenu.html';  ?>

	<div class="col-12 containr">
		
		<?php include '../header.html'; ?>

		<?php include '../mainmenu.html'; ?>

		<div class="col-12 content">
			<div class="maincontent col-9">
				<h1>How this thing we are doing works?</h1>
				<p>
				Organisations who require volunteers’ services apply to us and similarly volunteers are also required to apply with us to participate in events of their interest. And we make the match to satisfy the needs of both the organisation and volunteers.
				</p>
				<p>
				You can choose which events you volunteer at. 
				</p>
				<p>
				We will update you regularly with details of upcoming events, however it is up to you which ones you choose to attend, depending on your availability.  We ask that you attend at least two events once you have attended one of our training days. 
				</p>


			</div>
			<div class="social col-3">
				<?php include '../social.html'; ?>
			</div>
		</div>

		<?php include '../twitter.html' ?>

	</div>

	<?php include '../footer.html'; ?>

</div>

</body>
</html>



