<!DOCTYPE html>
<html>
<head>
	<title>My Volunteer</title>
	<link rel="stylesheet" type="text/css" href="../index.css">
	<link rel="stylesheet" type="text/css" href="../home.css">
	<link rel="stylesheet" type="text/css" href="../menu.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

	<?php include '../headcontent.html'; ?>
  <meta charset="utf-8" />
  <!-- <base href="http://myvolunteer.in/" /> -->
  <meta name="keywords" content="Events, Volunteer, Volunteering, Volunteers, Management, Events, Dublin, Fingal, Ireland, good, practice, Volunteer, Centre, Ireland, Management dublin, ireland, retention, motivation, recruitment, experts, selection, software, better impact, volunteer impact, Fingal County Council" />
  <meta name="description" content="Volunteer Management at Events" />
</head>
<body>

<div class="col-12 wrapper">
	<?php include '../topmenu.html';  ?>

	<div class="col-12 containr">
		
		<?php include '../header.html'; ?>

		<?php include '../mainmenu.html'; ?>

		<div class="col-12 content">
			<div class="maincontent col-9">
				<h1>About Us</h1>
				<h2>Vision</h2>
				<p>
				My volunteer aims to build a special place in the hearts of the volunteers who are willing to work in extravagant events but could not find one. We also wish to achieve a sense of satisfaction and promptness in the minds of the event’s organizers to work with us again since we provide with them the best skilled and confident volunteers with different areas of expertise.
				</p>

				<h2>Objectives</h2>
				<p>
				The main aim is to the basic guidelines of matching the right volunteer to the right place. We work hassle free and further target to reach as many places as we can throughout India for finding the desired candidate.
				</p>

				<h2>WHAT WE BELIEVE </h2>
				<p>
				We believe that as volunteers, command is your hand as volunteers are paid in six figures “Smiles" <br><br>Abraham Lincoln Rightly Said “He Has a Right to Criticise Who Has Heart to help”.
				</p>
				<p>
				Volunteering is not only about giving, but it is also a lite way of 
				living.
				</p>



			</div>
			<div class="social col-3">
				<?php include '../social.html'; ?>
			</div>
		</div>

		<?php include '../twitter.html' ?>

	</div>

	<?php include '../footer.html'; ?>

</div>

</body>
</html>



