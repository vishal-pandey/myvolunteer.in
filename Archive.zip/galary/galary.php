<!DOCTYPE html>
<html>
<head>
	<title>My Volunteer</title>
	<link rel="stylesheet" type="text/css" href="../index.css">
	<link rel="stylesheet" type="text/css" href="../home.css">
	<link rel="stylesheet" type="text/css" href="../menu.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	<?php include '../headcontent.html'; ?>


	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 70%;
      margin: auto;
  }
  </style>



  <meta charset="utf-8" />
  <!-- <base href="http://myvolunteer.in/" /> -->
  <meta name="keywords" content="Events, Volunteer, Volunteering, Volunteers, Management, Events, Dublin, Fingal, Ireland, good, practice, Volunteer, Centre, Ireland, Management dublin, ireland, retention, motivation, recruitment, experts, selection, software, better impact, volunteer impact, Fingal County Council" />
  <meta name="description" content="Volunteer Management at Events" />
</head>
<body>

<div class="col-12 wrapper">
	<?php include '../topmenu.html';  ?>

	<div class="col-12 containr">
		
		<?php include '../header.html'; ?>

		<?php include '../mainmenu.html'; ?>

		<div class="col-12 content">
			<div class="maincontent col-9">
				
				<h1>Gallery</h1>
				<div class="col-12">
					<a data-pin-do="embedBoard" data-pin-board-width="800" data-pin-scale-height="240" data-pin-scale-width="80" href="https://www.pinterest.com/mvolunteer/organisation-to-join/"></a>
					
				</div>
				



			</div>
			<div class="social col-3">
				<?php include '../social.html'; ?>
			</div>
		</div>

		<?php include '../twitter.html' ?>

	</div>

	<?php include '../footer.html'; ?>

</div>



<script async defer src="//assets.pinterest.com/js/pinit.js"></script>
</body>
</html>



