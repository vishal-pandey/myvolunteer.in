<!DOCTYPE html>
<html>
<head>
	<title>My Volunteer</title>
	<link rel="stylesheet" type="text/css" href="index.css">
	<link rel="stylesheet" type="text/css" href="home.css">
	<link rel="stylesheet" type="text/css" href="menu.css">
	<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
	<?php include 'headcontent.html'; ?>


	
  <style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 70%;
      margin: auto;
  }
  </style>



  <meta charset="utf-8" />
  <!-- <base href="http://myvolunteer.in/" /> -->
  <meta name="keywords" content="Events, Volunteer, Volunteering, Volunteers, Management, Events, Dublin, Fingal, Ireland, good, practice, Volunteer, Centre, Ireland, Management dublin, ireland, retention, motivation, recruitment, experts, selection, software, better impact, volunteer impact, Fingal County Council" />
  <meta name="description" content="Volunteer Management at Events" />
</head>
<body>

<div class="col-12 wrapper">
	<?php include 'topmenu.html';  ?>

	<div class="col-12 containr">
		
		<?php include 'header.html'; ?>

		<?php include 'mainmenu.html'; ?>

		<div class="col-12 content">
			<div class="maincontent col-9">
				<div class="slider">

					<div class="contain">
					  <br>
					  <div id="myCarousel" class="carousel slide" data-ride="carousel">
					    <!-- Indicators -->
					    <ol class="carousel-indicators">
					      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
					      <li data-target="#myCarousel" data-slide-to="1"></li>
					      <li data-target="#myCarousel" data-slide-to="2"></li>
					      <li data-target="#myCarousel" data-slide-to="3"></li>
					    </ol>

					    <!-- Wrapper for slides -->
					    <div class="carousel-inner" role="listbox">

					      <div class="item active">
					        <img src="./pics/1.jpg" alt="Chania" width="460" height="345">
					        <div class="carousel-caption">
					          <h3></h3>
					          <p></p>
					        </div>
					      </div>

					      <div class="item">
					        <img src="./pics/4.jpg" alt="Chania" width="460" height="345">
					        <div class="carousel-caption">
					          <h3></h3>
					          <p></p>
					        </div>
					      </div>
					    
					      <div class="item">
					        <img src="./pics/5.jpg" alt="Flower" width="460" height="345">
					        <div class="carousel-caption">
					          <h3></h3>
					          <p></p>
					        </div>
					      </div>

					      <div class="item">
					        <img src="./pics/6.jpg" alt="Flower" width="460" height="345">
					        <div class="carousel-caption">
					          <h3></h3>
					          <p></p>
					        </div>
					      </div>
  
					    </div>

					    <!-- Left and right controls -->
					    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
					      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					      <span class="sr-only">Previous</span>
					    </a>
					    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
					      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					      <span class="sr-only">Next</span>
					    </a>
					  </div>
					</div>

					
				</div>
				<h1>Welcome to My Volunteer</h1>
				<h2>Introduction</h2>
				<p>
					Our Lives in this modern era comprises of a lot of things now days. One such thing is Events, which has eventually become an important part in today’s society. Lives can be transformed through a wide range of events taking place, so we make it our business to ensure that it is easy for people to volunteer to get involved with public events, social events as well as commercial events (like exhibitions, seminars, conferences, social and promotional events TV ads and movies shoots etc.)  And that our Event Volunteers get the most out of their participation.
				</p>
				<p>
					But no event anywhere can be successfully completed without involvement of dedicated people known as Volunteers. Now the people organising the events need good volunteers and volunteers also requires right type of events to work for. Here we comes, to remove the gap between event organizers and volunteers. Volunteering with my Volunteer is an opportunity to put your skills to use in one of the most diverse communities in the country. We offers recruiters the ability to find suitable people on the basis of the criteria like age, experience, education, skills and build details. You will have the chance to develop new skills, meet new people and be a part of some of the biggest events. And at the same time, jobs seeker gets a medium to showcase their profiles. 
				</p>
				<p>
					If you are aged 16 or over (18 in the case of some events) and are motivated to be part of some great events then you are eligible to apply to be a My Volunteer. You can fill out an online application form and we will review your application.  If you are suitable we will then contact you with details of upcoming events.
				</p>



				<h2>Why Volunteer? </h2>
				<p>
					Volunteering offers vital help to people in need, worthwhile causes, and the community, but the benefits can be even greater for you, the volunteer. Volunteering and helping others can help you reduce stress, combat depression, keep you mentally stimulated, and provide a sense of purpose. While it’s true that the more you volunteer, the more benefits you’ll experience, volunteering doesn’t have to involve a long-term commitment or take a huge amount of time out of your busy day. Giving in even simple ways can help others those in need and improve your health and happiness.
				</p>



				<h2>Benefits Of Volunteering</h2>
				<p>
					4 ways to feel healthier and happier...
					<ol>
						<li>Volunteering connects you to others</li>
						<li>Volunteering is good for your mind and body</li>
						<li>Volunteering can advance your career</li>
						<li>Volunteering brings fun and fulfillment to your life</li>
					</ol>
				</p>				
			</div>
			<div class="social col-3">
				<?php include './social.html'; ?>
			</div>
		</div>

		<?php include 'twitter.html' ?>

	</div>

	<?php include 'footer.html'; ?>

</div>

</body>
</html>



